package com.tictactoe.actions;

public class GameTypeScore {
    public final static int WITH_FRIEND = 25;
    public final static int PC_EASY = 5;
    public final static int PC_MEDIAM = 15;
    public final static int PC_HARD = 25;
}
