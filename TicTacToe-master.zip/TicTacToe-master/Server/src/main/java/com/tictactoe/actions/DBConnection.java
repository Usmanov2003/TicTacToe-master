package com.tictactoe.actions;

import com.tictactoe.database.DatabaseManager;
import com.tictactoe.database.playerModel.Player;
import com.tictactoe.database.playerModel.PlayerModel;

import java.util.Vector;

public interface DBConnection {
    public final static DatabaseManager db = new DatabaseManager();


}
