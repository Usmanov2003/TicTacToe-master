package com.tictactoe.actions;

public enum RequestType {
    REQUEST,ANSWER
}
